# Flask y dependencias
from flask import Flask, request, render_template, redirect, url_for, flash, session, make_response, jsonify
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from werkzeug.security import generate_password_hash, check_password_hash

# Conexión a base de datos y fecha
import mysql.connector
from datetime import datetime

# Módulos personalizados para scraping de juegos
from scraping.juegos import obtener_juegos, obtener_plataformas_por_juego, obtener_genero_por_juego

# Utilidades adicionales
from functools import wraps
import requests
from bs4 import BeautifulSoup

# Configuración básica de la app Flask
app = Flask(__name__)
app.secret_key = 'clave-secreta'  # Clave para sesiones
app.config['JWT_SECRET_KEY'] = 'clave-jwt'  # Clave para JWT
jwt = JWTManager(app)

# Conexión a base de datos MySQL
# IMPORTANTE: Sustituir los datos de conexión por los propios
db = mysql.connector.connect(
    host="localhost",
    user="tu_usuario",
    password="tu_contraseña",
    database="videojuegos_db"
)

cursor = db.cursor(buffered=True)

# Creación de tablas si no existen
cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    nombre VARCHAR(100),
    apellido VARCHAR(100),
    plataforma_fav VARCHAR(100),
    sexo VARCHAR(10),
    juego_recomendado VARCHAR(100)
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS games (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    nombre_juego VARCHAR(100),
    genero VARCHAR(100),
    plataforma VARCHAR(100),
    fecha_inicio DATE,
    fecha_fin DATE,
    en_progreso BOOLEAN,
    horas_jugadas INT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
)
""")

db.commit()

# Ruta de inicio
@app.route('/')
def index():
    return render_template('index.html')

# Función para calcular la recomendación de un juego por género

def obtener_recomendacion(usuario_id):
    cursor.execute("""
        SELECT nombre_juego, genero, fecha_inicio, fecha_fin
        FROM games
        WHERE user_id = %s
    """, (usuario_id,))
    juegos = cursor.fetchall()

    if not juegos:
        return None, None

    genero_horas = {}
    juegos_jugados = set()

    for nombre, genero, fecha_inicio, fecha_fin in juegos:
        juegos_jugados.add(nombre)
        try:
            if fecha_inicio and fecha_fin:
                if isinstance(fecha_inicio, str):
                    fecha_inicio = datetime.fromisoformat(fecha_inicio)
                if isinstance(fecha_fin, str):
                    fecha_fin = datetime.fromisoformat(fecha_fin)

                delta = fecha_fin - fecha_inicio
                horas = delta.total_seconds() / 3600
            else:
                horas = 0

            genero_horas[genero] = genero_horas.get(genero, 0) + horas
        except Exception as e:
            continue

    if not genero_horas:
        return None, None

    genero_mas_jugado = max(genero_horas, key=genero_horas.get)

    cursor.execute("""
        SELECT nombre_juego, genero, fecha_inicio
        FROM games
        WHERE genero = %s AND user_id != %s
        ORDER BY fecha_inicio DESC
    """, (genero_mas_jugado, usuario_id))

    posibles = cursor.fetchall()

    for juego, genero, _ in posibles:
        if juego not in juegos_jugados:
            return juego, genero

    return None, genero_mas_jugado


# Endpoint para obtener recomendación en formato JSON
@app.route('/api/recommendation')
def api_recommendation():
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'}), 401

    usuario_id = session['user_id']

    try:
        juego_recomendado, genero = obtener_recomendacion(usuario_id)
        return jsonify({
            'juego_recomendado': juego_recomendado,
            'genero': genero
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Resto de rutas (registro, login, dashboard, add_game, edit_game, logout...)
# Se recomienda modularizar en archivos separados (auth.py, views.py, models.py, etc.)
# Aquí se ha simplificado por motivos de presentación.

# Ruta para obtener la fecha de lanzamiento de un juego desde Wikipedia
@app.route('/api/game_release_date')
def game_release_date():
    game_name = request.args.get('game')
    if not game_name:
        return jsonify({"error": "No game specified"}), 400

    try:
        search_url = f"https://es.wikipedia.org/wiki/{game_name.replace(' ', '_')}"
        resp = requests.get(search_url)
        if resp.status_code != 200:
            return jsonify({"error": "Game not found"}), 404

        soup = BeautifulSoup(resp.text, 'html.parser')
        infobox = soup.find('table', {'class': 'infobox'})
        if infobox:
            rows = infobox.find_all('tr')
            for row in rows:
                header = row.find('th')
                if header and 'lanzamiento' in header.text.lower():
                    td = row.find('td')
                    if td:
                        fecha_lanzamiento = td.text.strip().split('\n')[0]
                        return jsonify({"release_date": fecha_lanzamiento})

        return jsonify({"error": "Release date not found"}), 404

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# Iniciar servidor en modo debug
if __name__ == '__main__':
    app.run(debug=True)
