import requests
from bs4 import BeautifulSoup

BASE_WIKI = "https://en.wikipedia.org"

# Obtiene los nombres de los 100 videojuegos más vendidos desde Wikipedia
def obtener_juegos():
    url = f"{BASE_WIKI}/wiki/List_of_best-selling_video_games"
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")

    juegos = []

    # Recorre las filas de la tabla (excepto el encabezado)
    for row in soup.select("table.wikitable tbody tr")[1:]:
        columna = row.find("i")  # Normalmente el título está en cursiva
        if columna and columna.a:
            nombre = columna.a.text.strip()
            juegos.append(nombre)

    return juegos[:100]  # Solo los 100 primeros juegos


# Devuelve una lista fija de géneros predefinidos
def obtener_generos():
    return ["Acción", "Aventura", "Deportes", "RPG", "Simulación", "Estrategia", "Shooter"]


# Dado el nombre de un juego, intenta extraer las plataformas desde su infobox
def obtener_plataformas_por_juego(nombre_juego):
    juegos = obtener_juegos()
    if nombre_juego not in juegos:
        return []

    nombre_url = nombre_juego.replace(" ", "_")
    url = f"{BASE_WIKI}/wiki/{nombre_url}"

    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")

        infobox = soup.find("table", class_="infobox")
        if not infobox:
            return []

        filas = infobox.find_all("tr")
        for fila in filas:
            th = fila.find("th")
            if th and "platform" in th.text.lower():
                plataformas = fila.find("td")
                if plataformas:
                    links = plataformas.find_all("a")
                    nombres = [a.text.strip() for a in links if a.text.strip()]
                    return list(set(nombres))  # Eliminar duplicados
    except Exception as e:
        print(f"[ERROR plataformas] {nombre_juego}: {e}")

    return []


# Dado el nombre de un juego, intenta extraer su(s) género(s) desde el infobox
def obtener_genero_por_juego(nombre_juego):
    nombre_url = nombre_juego.replace(" ", "_")
    url = f"{BASE_WIKI}/wiki/{nombre_url}"

    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")

        infobox = soup.find("table", class_="infobox")
        if not infobox:
            return None

        for fila in infobox.find_all("tr"):
            th = fila.find("th")
            if th and "genre" in th.text.lower():
                td = fila.find("td")
                if td:
                    generos = [a.text.strip() for a in td.find_all("a")]
                    return ", ".join(generos) if generos else td.text.strip()
    except Exception as e:
        print(f"[ERROR género] {nombre_juego}: {e}")

    return None
